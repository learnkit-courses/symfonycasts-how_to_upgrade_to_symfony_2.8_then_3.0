Upgrading to Symfony 2.8, then 3.0!
===================================

Well hi there! This repository holds the code and script
for the Upgrade to Symfony 3 tutorial.

Have fun!
